# AskMe V1

AskMe is a 13+ social Q&A prototype.

## Design direction
- Light theme by default
- AskMe blue/purple/pink gradient branding
- Dark mode and system appearance are available
- Premium theme customization is included in the UI
- Gallery themes are reserved for Premium
- Mature social-media styling, not childish styling

## Included
- Responsive Home feed
- Discover/search
- Notifications
- Inbox foundation
- Profile
- TikTok-style Settings & Privacy structure
- Appearance controls
- Question composer
- Anonymous questions
- Likes and saves
- Persistent JSON backend
- Premium screen and theme controls
- Device/internet information screen

## Run locally

Install Node.js, then:

    npm install
    npm start

Open:

    http://localhost:3000

This is a V1 prototype. Production authentication, real-time messaging/calls, secure media storage, moderation infrastructure, payments, and a production database still need to be added before launch.


## V2 product direction
- Inbox: iMessage-inspired messaging experience with chat list, bubbles, compose bar, calls and requests.
- Overall structure: Instagram-inspired profile/navigation/content organization.
- Home/FYP: Threads-inspired text-first feed with questions and conversations.
- Vibe: Snapchat-inspired social, casual, visual feel without copying its UI.
- Settings: TikTok-inspired Settings & privacy organization.
- These are design-direction references; AskMe uses its own branding and UI.


## V3 — FYP/Home upgrade
- Threads-inspired text-first For You feed
- Story-style top row for a more social/Snap-like feel
- For You / Following / Trending tabs
- Question cards with like, answer, save and share actions
- Answer modal foundation
- Native share support when available
- Improved Ask modal reset and posting flow


## V4 — Inbox upgrade
- iMessage-inspired conversation list
- Search messages
- Message requests
- One-to-one chat screen
- Send text messages in the prototype
- Voice-message button foundation
- Voice/video call interface foundation
- Online/active indicators
- Mobile-friendly chat layout


# ASKME FINAL PROTOTYPE SCOPE

This final prototype brings the planned product areas into one app shell:
- Home/FYP with For You, Following and Trending direction
- Questions, anonymous questions, likes, answers, saves and sharing
- Inbox with requests, text chat, voice/call/video-call UI foundations
- Profiles, follower/following structure and profile editing UI
- Search and social discovery foundations
- Notifications
- TikTok-inspired settings organization
- Light/dark/system appearance
- Premium area with custom/gallery theme direction
- Safety/report/block foundations
- Responsive mobile, tablet and desktop styling
- JSON persistence for prototype data

Production launch still requires real authentication, a production database, encrypted sessions, real media storage/CDN, real-time messaging/calling infrastructure, payment processing, moderation operations and platform-specific app packaging.


# AskMe 2.0 — production foundation

Added in this build:
- Secure password hashing with Node scrypt
- Session tokens
- Sign-up / sign-in / logout API
- Authenticated questions, likes, saves, follows and messages
- Persistent message storage
- WebSocket realtime message delivery foundation
- Rate limiting on API routes
- Profile editing and account/privacy foundations
- Notifications, reports and blocking APIs
- PWA manifest and service worker
- Responsive app shell retained from the final prototype

Before public launch, connect:
- a managed production database
- HTTPS and secure cookie/session storage
- object/media storage + CDN
- TURN/STUN + signaling for production voice/video calls
- a payment provider for Premium
- email/phone verification and account recovery
- professional moderation/admin operations
- Android/iOS store builds and signing
