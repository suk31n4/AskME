let questions=[];
const page=document.getElementById("page");
const title=document.getElementById("pageTitle");
const desc=document.getElementById("pageDescription");

const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const ago=d=>{let m=Math.floor((Date.now()-new Date(d))/60000);if(m<1)return"now";if(m<60)return m+"m";let h=Math.floor(m/60);if(h<24)return h+"h";return Math.floor(h/24)+"d"};

async function load(){
  const r=await fetch("/api/feed"); questions=await r.json(); renderHome(questions);
}
function avatar(n){return `<div class="avatar">${esc(n[0]||"A").toUpperCase()}</div>`}
function card(q){
 return `<article class="card">
   <div class="meta">${avatar(q.author)}<div><b>${esc(q.author)}</b><small> · ${ago(q.createdAt)}</small></div></div>
   <div class="question">${esc(q.text)}</div>
   <span class="tag">${esc(q.category)}</span>
   <div class="actions">
     <button onclick="likeQ('${q.id}')">♡ ${q.likes}</button>
     <button>◯ ${q.answers} answers</button>
     <button onclick="saveQ('${q.id}')">◇ ${q.saves}</button>
     <button>↗ Share</button>
   </div>
 </article>`;
}
function renderHome(list){
 title.textContent="For You";
 desc.textContent="Questions, conversations and people you may want to hear from.";
 page.innerHTML=`
 <div class="story-row">
   ${["Your story","Following","Music","School","Life","Art"].map((x,i)=>`
   <button class="story"><div class="story-ring"><div>${i===0?"+":x[0]}</div></div>${x}</button>`).join("")}
 </div>
 <div class="composer">
   <div class="avatar">S</div>
   <button class="fake-input" id="quickAsk">What's on your mind?</button>
 </div>
 <div class="tabs">
   <button class="tab active">For you</button>
   <button class="tab">Following</button>
   <button class="tab">Trending</button>
 </div>
 <div id="feed-list">
 ${list.length ? list.map(fypCard).join("") : '<div class="empty">No questions found.</div>'}
 </div>`;
 document.getElementById("quickAsk").onclick=openAsk;
}
function fypCard(q){
 return `<article class="fyp-card" data-id="${q.id}">
   <div class="fyp-head">${avatar(q.author)}
     <div><b>${esc(q.author)}</b><small style="color:var(--muted)"> · ${ago(q.createdAt)}</small></div>
     <button class="more-btn">•••</button>
   </div>
   <div class="fyp-body">
     <span class="tag">${esc(q.category)}</span>
     <div class="fyp-question">${esc(q.text)}</div>
   </div>
   <div class="fyp-actions">
     <button class="like-action" onclick="likeQ('${q.id}')">♡ <span>${q.likes}</span></button>
     <button onclick="openAnswers('${q.id}')">◯ <span>${q.answers}</span></button>
     <button class="save-action" onclick="saveQ('${q.id}')">◇ <span>${q.saves}</span></button>
     <button onclick="shareQ('${q.id}')">↗</button>
   </div>
 </article>`;
}
function openAnswers(id){
 const q=questions.find(x=>x.id===id);
 if(!q)return;
 document.getElementById("askModal").classList.remove("hidden");
 document.querySelector(".modal-card").innerHTML=`
   <button class="close" onclick="closeAsk()">×</button>
   <span class="tag">${esc(q.category)}</span>
   <h2 style="margin-top:12px">${esc(q.text)}</h2>
   <p>Answers will appear here.</p>
   <textarea placeholder="Write an answer..."></textarea>
   <button class="gradient-button" onclick="closeAsk()">Post answer</button>`;
}
function shareQ(id){
 const q=questions.find(x=>x.id===id);
 if(!q)return;
 if(navigator.share) navigator.share({title:"AskMe",text:q.text});
 else navigator.clipboard?.writeText(q.text);
}

function renderNotifications(){
 title.textContent="Notifications";desc.textContent="What’s happening on AskMe.";
 page.innerHTML=`<div class="settings-card"><h2>Notifications</h2>
 <div class="notice-row"><b>♡</b><span>Someone liked your question<small>2m ago</small></span></div>
 <div class="notice-row"><b>＋</b><span>You have a new follower<small>18m ago</small></span></div>
 <div class="notice-row"><b>◯</b><span>Your question received an answer<small>1h ago</small></span></div></div>`;
}
function renderSettings(){
 title.textContent="Settings";desc.textContent="Manage your AskMe experience.";
 page.innerHTML=`<div class="settings-grid">
 ${[
 ["Account","Edit profile · Username · Email"],
 ["Privacy","Private account · Mentions · Blocked users"],
 ["Notifications","Push notifications · Email alerts"],
 ["Messages & calls","Requests · Voice · Video calls"],
 ["Appearance","Light · Dark · System"],
 ["Premium","Custom themes · Gallery backgrounds · Badge"],
 ["Safety","Reports · Restrictions · Community rules"],
 ["Language","English · Kiswahili"]
 ].map((x,i)=>`<button class="setting-item" data-setting="${i}"><span>${x[0]}</span><small>${x[1]}</small><b>›</b></button>`).join("")}
 <div class="premium-banner"><strong>AskMe Premium</strong><p>Unlock custom themes, gallery backgrounds, chat themes and profile customization.</p><button class="gradient-button" id="premiumBtn">Explore Premium</button></div>
 </div>`;
 document.querySelectorAll(".setting-item").forEach(b=>b.onclick=()=>openSetting(b.dataset.setting));
 document.getElementById("premiumBtn").onclick=openPremium;
}
function openSetting(i){
 const names=["Account","Privacy","Notifications","Messages & calls","Appearance","Premium","Safety","Language"];
 document.getElementById("askModal").classList.remove("hidden");
 document.querySelector(".modal-card").innerHTML=`<button class="close" onclick="closeAsk()">×</button><h2>${names[i]}</h2>
 <p class="muted">These controls are part of the AskMe prototype. Your choices can be connected to the production account system later.</p>
 ${i==="4"?'<div class="theme-options"><button onclick="setTheme("light")">Light</button><button onclick="setTheme("dark")">Dark</button><button onclick="setTheme("system")">System</button></div>':''}
 ${i==="6"?'<button class="outline-btn" onclick="reportDemo()">Report a problem</button><button class="outline-btn" onclick="closeAsk()">Community rules</button>':''}`;
}
function setTheme(mode){
 document.body.dataset.theme=mode;
 if(mode==="dark")document.body.classList.add("dark");else if(mode==="light")document.body.classList.remove("dark");else document.body.classList.toggle("dark",matchMedia("(prefers-color-scheme:dark)").matches);
}
function openPremium(){
 document.getElementById("askModal").classList.remove("hidden");
 document.querySelector(".modal-card").innerHTML=`<button class="close" onclick="closeAsk()">×</button><div class="premium-modal"><div class="premium-icon">✦</div><h2>AskMe Premium</h2><p>Make AskMe feel like yours.</p><ul><li>Custom app themes</li><li>Use a photo from your gallery as a theme</li><li>Custom chat themes</li><li>Profile customization</li><li>Premium badge</li><li>Early access to features</li></ul><button class="gradient-button" onclick="closeAsk()">Continue</button></div>`;
}
function reportDemo(){
 fetch("/api/report",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({reason:"User report from prototype"})});
 closeAsk();
}
function simple(name,text){
 title.textContent=name; desc.textContent="";
 page.innerHTML=`<div class="empty">${text}</div>`;
}
async function renderProfile(username="sukeina"){
 title.textContent=username==="sukeina"?"Profile":`@${username}`;
 desc.textContent="Your AskMe space.";
 page.innerHTML=`<div class="profile-loading">Loading profile…</div>`;
 try{
  const r=await fetch("/api/profile/"+encodeURIComponent(username)); const u=await r.json();
  page.innerHTML=`
   <section class="profile-page">
    <div class="profile-cover"></div>
    <div class="profile-main">
      <div class="profile-avatar-large">${(u.displayName||u.username||"S")[0].toUpperCase()}</div>
      <div class="profile-actions">${username==="sukeina"?'<button class="outline-btn" id="editProfile">Edit profile</button>':'<button class="gradient-button small" id="followBtn">Follow</button>'}</div>
      <h1>${esc(u.displayName||u.username)}</h1><p class="handle">@${esc(u.username)}</p>
      <p>${esc(u.bio||"Ask questions. Share answers. Find your people.")}</p>
      <div class="profile-stats"><b>${(u.followers||[]).length}<span>followers</span></b><b>${(u.following||[]).length}<span>following</span></b><b>${(u.posts||[]).length}<span>questions</span></b></div>
      <div class="profile-tabs"><button class="active">Questions</button><button>Replies</button><button>Saved</button></div>
      <div class="profile-posts">${(u.posts||[]).map(fypCard).join("")||'<div class="empty">Nothing here yet.</div>'}</div>
    </div>
   </section>`;
  if(username==="sukeina")document.getElementById("editProfile").onclick=()=>openEditProfile(u);
  else document.getElementById("followBtn").onclick=async()=>{await fetch("/api/follow/"+encodeURIComponent(username),{method:"POST"});renderProfile(username)};
 }catch(e){page.innerHTML='<div class="empty">Could not load profile.</div>'}
}
function openEditProfile(u){
 document.getElementById("askModal").classList.remove("hidden");
 document.querySelector(".modal-card").innerHTML=`
 <button class="close" onclick="closeAsk()">×</button><h2>Edit profile</h2>
 <input id="editName" value="${esc(u.displayName||"")}" placeholder="Display name">
 <textarea id="editBio" placeholder="Bio">${esc(u.bio||"")}</textarea>
 <button class="gradient-button" onclick="closeAsk()">Save changes</button>`;
}

function row(icon,name,sub,action="›"){return `<button class="setting-row" onclick="${action}">
 <span class="setting-icon">${icon}</span><span class="setting-copy"><b>${name}</b>${sub?`<small>${sub}</small>`:""}</span><span class="chev">›</span></button>`}
function renderSettings(){
 title.textContent="Settings & privacy";desc.textContent="Manage your account, privacy, content and app preferences.";
 page.innerHTML=`<div class="settings">
 <h2>Account</h2><div class="settings-group">
 ${row("●","Account","Manage your account")}
 ${row("⌁","Password & security","Security and login")}
 ${row("◉","Privacy","Private account and interaction controls")}
 ${row("♡","Notifications","Choose what you receive")}
 ${row("⊘","Blocked accounts","Manage blocked users")}
 </div>
 <h2>Content & activity</h2><div class="settings-group">
 ${row("◌","Content preferences","Manage recommendations")}
 ${row("◇","Saved questions","Your saved content")}
 ${row("◷","Activity history","Review your activity")}
 ${row("文","Language","English")}
 </div>
 <h2>Messages & calls</h2><div class="settings-group">
 ${row("▢","Direct messages","Who can message you")}
 ${row("♬","Voice messages","Voice-message settings")}
 ${row("☎","Calls","Voice and video calls")}
 </div>
 <h2>Appearance</h2><div class="settings-group">
 ${row("☼","Light","Default")}
 ${row("◐","Dark","Optional")}
 ${row("◌","System","Follow your device")}
 </div>
 <div class="premium-card"><b>AskMe Premium</b><p>Make AskMe yours with custom themes and extra profile features.</p><button onclick="renderThemes()">Explore Premium</button></div>
 <h2>Safety & support</h2><div class="settings-group">
 ${row("✓","Safety center","Privacy and safety tools")}
 ${row("?","Report a problem","Get help with AskMe")}
 ${row("i","About AskMe","13+ · Community guidelines")}
 </div>
 </div>`;
}
function renderThemes(){
 title.textContent="Themes";desc.textContent="Premium customization";
 page.innerHTML=`<div class="card"><b>Choose your appearance</b><p style="color:var(--muted);font-size:12px">Standard appearance is free. Advanced customization is Premium.</p>
 <div class="theme-grid">
 <button class="theme-tile selected" onclick="setTheme('light')"><div class="theme-preview" style="background:#f7f8fb;color:#171a22">Light<br>Default</div><span class="theme-name" style="color:#333;text-shadow:none">Light</span></button>
 <button class="theme-tile" onclick="setTheme('dark')"><div class="theme-preview" style="background:#08111f;color:#fff">Dark<br>Optional</div><span class="theme-name">Dark</span></button>
 <button class="theme-tile"><div class="theme-preview ocean"></div><span class="theme-name">Ocean · Premium</span></button>
 <button class="theme-tile"><div class="theme-preview rose"></div><span class="theme-name">Rose · Premium</span></button>
 <button class="theme-tile"><div class="theme-preview forest"></div><span class="theme-name">Forest · Premium</span></button>
 <button class="theme-tile"><div class="theme-preview gallery"></div><span class="theme-name">Use Gallery · Premium</span></button>
 </div></div>
 <div class="card"><h3 style="margin-top:0">Gallery themes</h3><p style="color:var(--muted);font-size:12px">Premium users can choose a photo from their gallery and use it as a customized app or chat background.</p><button class="gradient-button" onclick="alert('Gallery theme selection will connect to device photo access in the production app.')">Choose from gallery</button></div>`;
}
function setTheme(t){document.body.classList.toggle("dark",t==="dark");localStorage.setItem("askme-theme",t)}
document.querySelectorAll(".nav,.bottom-nav button[data-page]").forEach(b=>b.addEventListener("click",()=>{
 const p=b.dataset.page;document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===p));
 if(p==="home")renderHome(questions);
 else if(p==="profile")renderProfile();
 else if(p==="settings")renderSettings();
 else if(p==="discover")simple("Discover","Search people, questions and topics.");
 else if(p==="notifications")simple("Notifications","You're all caught up.");
 else if(p==="inbox")renderInbox();
 else if(p==="saved")simple("Saved","Questions you save will appear here.");
}));
document.getElementById("mobileSettings").onclick=renderSettings;
document.getElementById("focusSearch").onclick=()=>document.getElementById("search").focus();
const modal=document.getElementById("askModal");
function openAsk(){resetAskModal();modal.classList.remove("hidden");document.getElementById("question").focus()}
function closeAsk(){modal.classList.add("hidden")}
document.getElementById("openAsk").onclick=openAsk;
document.getElementById("bottomAsk").onclick=openAsk;
document.getElementById("closeAsk").onclick=closeAsk;
modal.addEventListener("click",e=>{if(e.target===modal)closeAsk()});
document.getElementById("postQuestion").onclick=postQuestion;
async function likeQ(id){await fetch("/api/questions/"+id+"/like",{method:"POST"});load()}
async function saveQ(id){await fetch("/api/questions/"+id+"/save",{method:"POST"});load()}
function resetAskModal(){
 document.querySelector(".modal-card").innerHTML=`
 <button class="close" id="closeAsk">×</button>
 <h2>Ask a question</h2>
 <p>Ask publicly or anonymously.</p>
 <textarea id="question" maxlength="500" placeholder="What's on your mind?"></textarea>
 <div class="form-line">
   <select id="category"><option>General</option><option>Life</option><option>Education</option><option>Music</option><option>Art</option><option>Technology</option><option>Entertainment</option><option>Sports</option></select>
   <label><input type="checkbox" id="anon"> Ask anonymously</label>
 </div>
 <button class="gradient-button" id="postQuestion">Post question</button>`;
 document.getElementById("closeAsk").onclick=closeAsk;
 document.getElementById("postQuestion").onclick=postQuestion;
}
async function postQuestion(){
 const text=document.getElementById("question").value.trim(); if(!text)return;
 const r=await fetch("/api/questions",{method:"POST",headers:{"Content-Type":"application/json"},
 body:JSON.stringify({text,category:document.getElementById("category").value,anonymous:document.getElementById("anon").checked})});
 if(r.ok){closeAsk();resetAskModal();load();}
}
document.getElementById("search").addEventListener("input",e=>{let q=e.target.value.toLowerCase();renderHome(questions.filter(x=>(x.text+" "+x.category+" "+x.author).toLowerCase().includes(q)))});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeAsk()});
const savedTheme=localStorage.getItem("askme-theme"); if(savedTheme==="dark")document.body.classList.add("dark");
load();

// Final navigation helpers
window.AskMeNav={home:()=>load(),profile:()=>renderProfile(),settings:()=>renderSettings(),notifications:()=>renderNotifications()};


// Production-foundation authentication helpers.
const ASKME_TOKEN_KEY="askme_token";
const askmeToken=()=>localStorage.getItem(ASKME_TOKEN_KEY);
const askmeFetch=window.fetch;
window.fetch=async (url,opts={})=>{
  if(String(url).startsWith("/api/")){
    opts.headers=Object.assign({},opts.headers||{});
    const t=askmeToken(); if(t)opts.headers.Authorization="Bearer "+t;
  }
  return askmeFetch(url,opts);
};
function showAuth(){
  const modal=document.getElementById("askModal"); if(!modal)return;
  modal.classList.remove("hidden");
  document.querySelector(".modal-card").innerHTML=`<div class="auth-box">
   <div class="premium-icon">✦</div><h2>Welcome to AskMe</h2><p class="muted">Sign in or create your 13+ account.</p>
   <input id="authUser" placeholder="Username">
   <input id="authPass" type="password" placeholder="Password">
   <input id="authName" placeholder="Display name (for sign up)">
   <div class="auth-buttons"><button class="gradient-button" id="authLogin">Sign in</button><button class="outline-btn" id="authSignup">Create account</button></div>
   <small id="authError"></small></div>`;
  const msg=x=>document.getElementById("authError").textContent=x;
  document.getElementById("authLogin").onclick=async()=>{
   const r=await askmeFetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:authUser.value,password:authPass.value})});
   const d=await r.json(); if(!r.ok)return msg(d.error||"Could not sign in");localStorage.setItem(ASKME_TOKEN_KEY,d.token);closeAsk();location.reload();
  };
  document.getElementById("authSignup").onclick=async()=>{
   const r=await askmeFetch("/api/auth/signup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:authUser.value,password:authPass.value,displayName:authName.value})});
   const d=await r.json(); if(!r.ok)return msg(d.error||"Could not create account");localStorage.setItem(ASKME_TOKEN_KEY,d.token);closeAsk();location.reload();
  };
}
