# AskMe — run it

## Windows
1. Install Node.js.
2. Double-click `start.bat`.
3. AskMe opens at http://localhost:3000.

## Mac/Linux
1. Install Node.js.
2. Open Terminal in this folder.
3. Run `./start.sh`.

## Phone
AskMe is packaged as a PWA. Once the site is hosted over HTTPS, open it in the phone browser and use **Add to Home Screen / Install app**.

The project includes the backend, database seed, responsive UI, PWA manifest, icons, messaging foundation, profiles, settings, Premium theme direction and safety APIs.

For a public release, the server needs real hosting plus a production database, HTTPS, media storage, call infrastructure, payments, account recovery/verification and moderation operations.
