@echo off
title AskMe
cd /d "%~dp0"
echo.
echo  ASKME
echo  Starting your app...
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js from https://nodejs.org/ and run this again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing app dependencies...
  call npm install
)
start "" http://localhost:3000
npm start
pause
