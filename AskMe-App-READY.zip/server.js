const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const http = require("http");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, "data", "db.json");
const sessions = new Map();
const rate = new Map();

app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname,"public")));

function readDB(){
  if(!fs.existsSync(DB)) return {users:[],questions:[],notifications:[],messages:[],reports:[]};
  return JSON.parse(fs.readFileSync(DB,"utf8"));
}
function saveDB(db){ fs.writeFileSync(DB,JSON.stringify(db,null,2)); }
function id(){ return crypto.randomUUID(); }
function hashPassword(password,salt=crypto.randomBytes(16).toString("hex")){
  return {salt,hash:crypto.scryptSync(password,salt,64).toString("hex")};
}
function checkPassword(password,salt,hash){
  const got=crypto.scryptSync(password,salt,64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(got,"hex"),Buffer.from(hash,"hex"));
}
function publicUser(u){
  return {username:u.username,displayName:u.displayName,bio:u.bio||"",followers:u.followers||[],following:u.following||[],private:!!u.private};
}
function auth(req,res,next){
  const token=(req.headers.authorization||"").replace(/^Bearer\s+/,"");
  const username=sessions.get(token);
  if(!username) return res.status(401).json({error:"Sign in required"});
  req.username=username; next();
}
function limited(key,windowMs=60000,max=60){
  const now=Date.now(), old=rate.get(key)||[];
  const fresh=old.filter(t=>now-t<windowMs);
  fresh.push(now); rate.set(key,fresh);
  return fresh.length>max;
}
function guard(req,res,next){
  const key=(req.ip||"unknown")+":"+req.path;
  if(limited(key)) return res.status(429).json({error:"Too many requests"});
  next();
}
app.use("/api",guard);

app.get("/api/health",(req,res)=>res.json({ok:true,service:"AskMe",time:new Date().toISOString()}));

app.post("/api/auth/signup",(req,res)=>{
  const username=String(req.body.username||"").trim().toLowerCase();
  const password=String(req.body.password||"");
  const displayName=String(req.body.displayName||username).trim();
  if(!/^[a-z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:"Username must be 3-24 letters, numbers or underscores"});
  if(password.length<8) return res.status(400).json({error:"Password must be at least 8 characters"});
  const db=readDB();
  if(db.users.some(u=>u.username===username)) return res.status(409).json({error:"Username already exists"});
  const hp=hashPassword(password);
  const user={id:id(),username,displayName,bio:"",salt:hp.salt,passwordHash:hp.hash,followers:[],following:[],blocked:[],private:false,createdAt:new Date().toISOString()};
  db.users.push(user); saveDB(db);
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,username);
  res.status(201).json({token,user:publicUser(user)});
});

app.post("/api/auth/login",(req,res)=>{
  const username=String(req.body.username||"").trim().toLowerCase();
  const password=String(req.body.password||"");
  const db=readDB(); const u=db.users.find(x=>x.username===username);
  if(!u || !u.passwordHash || !checkPassword(password,u.salt,u.passwordHash)) return res.status(401).json({error:"Invalid username or password"});
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,username);
  res.json({token,user:publicUser(u)});
});
app.post("/api/auth/logout",auth,(req,res)=>{
  const token=(req.headers.authorization||"").replace(/^Bearer\s+/,""); sessions.delete(token); res.json({ok:true});
});
app.get("/api/me",auth,(req,res)=>{
  const db=readDB(); const u=db.users.find(x=>x.username===req.username); res.json(publicUser(u));
});

app.get("/api/feed",(req,res)=>{
  const db=readDB(); let qs=db.questions||[];
  const mode=req.query.mode||"for-you";
  if(mode==="trending") qs=[...qs].sort((a,b)=>(b.likes+b.answers*2)-(a.likes+a.answers*2));
  if(mode==="following"){
    const u=db.users.find(x=>x.username==="sukeina");
    const following=u?.following||[];
    qs=qs.filter(q=>following.includes(q.author)||q.author==="sukeina");
  }
  res.json(qs);
});

app.post("/api/questions",auth,(req,res)=>{
  const text=String(req.body.text||"").trim();
  if(!text || text.length>500) return res.status(400).json({error:"Question must be 1-500 characters"});
  const db=readDB();
  const q={id:id(),author:req.body.anonymous?"Anonymous":req.username,anonymous:!!req.body.anonymous,
    category:String(req.body.category||"General"),text,likes:0,answers:0,saves:0,reposts:0,
    likedBy:[],savedBy:[],createdAt:new Date().toISOString()};
  db.questions.unshift(q); saveDB(db); res.status(201).json(q);
});
function toggleQuestion(req,res,field,listField){
  const db=readDB(), q=db.questions.find(x=>x.id===req.params.id);
  if(!q) return res.status(404).json({error:"Not found"});
  q[listField]=q[listField]||[]; const i=q[listField].indexOf(req.username);
  if(i>=0) q[listField].splice(i,1); else q[listField].push(req.username);
  q[field]=q[listField].length; saveDB(db); res.json(q);
}
app.post("/api/questions/:id/like",auth,(req,res)=>toggleQuestion(req,res,"likes","likedBy"));
app.post("/api/questions/:id/save",auth,(req,res)=>toggleQuestion(req,res,"saves","savedBy"));
app.post("/api/questions/:id/repost",auth,(req,res)=>{
  const db=readDB(),q=db.questions.find(x=>x.id===req.params.id); if(!q)return res.status(404).json({error:"Not found"});
  q.reposts=(q.reposts||0)+1; saveDB(db); res.json(q);
});

app.get("/api/profile/:username",(req,res)=>{
  const db=readDB(),u=db.users.find(x=>x.username===req.params.username);
  if(!u)return res.status(404).json({error:"User not found"});
  res.json({...publicUser(u),posts:db.questions.filter(q=>q.author===u.username)});
});
app.patch("/api/me",auth,(req,res)=>{
  const db=readDB(),u=db.users.find(x=>x.username===req.username);
  if(req.body.displayName!==undefined)u.displayName=String(req.body.displayName).slice(0,50);
  if(req.body.bio!==undefined)u.bio=String(req.body.bio).slice(0,160);
  if(req.body.private!==undefined)u.private=!!req.body.private;
  saveDB(db); res.json(publicUser(u));
});
app.post("/api/follow/:username",auth,(req,res)=>{
  const db=readDB(),me=db.users.find(x=>x.username===req.username),target=db.users.find(x=>x.username===req.params.username);
  if(!target)return res.status(404).json({error:"User not found"});
  me.following=me.following||[]; target.followers=target.followers||[];
  const i=me.following.indexOf(target.username);
  if(i>=0){me.following.splice(i,1);target.followers=target.followers.filter(x=>x!==me.username);}
  else {me.following.push(target.username);if(!target.followers.includes(me.username))target.followers.push(me.username);}
  saveDB(db);res.json({following:me.following});
});

app.get("/api/messages/:username",auth,(req,res)=>{
  const db=readDB(); const me=req.username,other=req.params.username;
  res.json((db.messages||[]).filter(m=>(m.from===me&&m.to===other)||(m.from===other&&m.to===me)));
});
app.post("/api/messages/:username",auth,(req,res)=>{
  const body=String(req.body.text||"").trim(); if(!body||body.length>2000)return res.status(400).json({error:"Invalid message"});
  const db=readDB(); const target=db.users.find(u=>u.username===req.params.username);
  if(!target)return res.status(404).json({error:"User not found"});
  const m={id:id(),from:req.username,to:target.username,text:body,createdAt:new Date().toISOString(),read:false};
  db.messages=db.messages||[];db.messages.push(m);saveDB(db);broadcast(target.username,{type:"message",message:m});res.status(201).json(m);
});

app.get("/api/notifications",auth,(req,res)=>{
  const db=readDB(); res.json((db.notifications||[]).filter(n=>n.username===req.username));
});
app.post("/api/report",auth,(req,res)=>{
  const db=readDB();db.reports=db.reports||[];db.reports.push({id:id(),username:req.username,...req.body,status:"pending",createdAt:new Date().toISOString()});saveDB(db);res.json({ok:true});
});
app.post("/api/block/:username",auth,(req,res)=>{
  const db=readDB(),u=db.users.find(x=>x.username===req.username);u.blocked=u.blocked||[];
  if(!u.blocked.includes(req.params.username))u.blocked.push(req.params.username);
  saveDB(db);res.json({ok:true});
});

const wss=new WebSocketServer({server,path:"/ws"});
const sockets=new Map();
function broadcast(username,payload){
  const set=sockets.get(username)||new Set();
  for(const ws of set) if(ws.readyState===1)ws.send(JSON.stringify(payload));
}
wss.on("connection",(ws,req)=>{
  const token=new URL(req.url,"http://localhost").searchParams.get("token");
  const username=sessions.get(token); if(!username){ws.close();return;}
  if(!sockets.has(username))sockets.set(username,new Set());sockets.get(username).add(ws);
  ws.on("close",()=>sockets.get(username)?.delete(ws));
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(PORT,()=>console.log(`AskMe running at http://localhost:${PORT}`));
