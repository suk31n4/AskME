#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is required."; exit 1; }
if [ ! -d node_modules ]; then npm install; fi
( sleep 2; (command -v xdg-open >/dev/null && xdg-open http://localhost:3000) || true ) &
npm start
