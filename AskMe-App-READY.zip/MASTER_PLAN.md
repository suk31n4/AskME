# ASKME MASTER PLAN — V1 BUILD

## Identity
- 13+ social Q&A and conversation platform
- Motto: "Your space. Your questions. Your people."
- Mature, clean, social-media style
- Not childish
- Light theme by default
- AskMe blue/cyan/purple/pink gradient branding
- Dark mode optional
- System appearance option

## Core
- Questions
- Answers
- Replies
- Likes
- Saves
- Sharing
- Reposts
- Following/followers
- Profiles
- Search
- Discover
- Trending
- Categories
- Notifications
- Anonymous questions
- Private accounts

## Messaging
- Inbox
- Direct messages
- Message requests
- Voice messages
- Voice calls
- Video calls
- Shared questions/posts

## Settings
TikTok-style Settings & Privacy organization:
- Account
- Password & security
- Privacy
- Notifications
- Blocked accounts
- Content preferences
- Saved questions
- Activity history
- Language
- Direct messages
- Voice messages
- Calls
- Appearance
- Safety center
- Help/report
- About

## Themes
- Light: default/free
- Dark: optional/free
- System: follows device
- Premium custom themes
- Premium chat themes
- Premium gallery themes
- Gallery photos can become backgrounds with readability controls

## Premium
- Custom app themes
- Gallery themes
- Custom chat themes
- Premium profile customization
- More profile options
- Premium badges
- Early feature access

## Monetization
- Free core app
- Ads
- Premium
- Promoted questions
- Future creator/business tools
- Future tips where permitted

## Safety
- Reporting
- Blocking
- Moderation
- Warnings
- Restrictions
- Suspensions
- Appeals
- Human moderator dashboard
- Age-appropriate safety controls

## Technical
- Responsive Android/iPhone/tablet/web UI
- Medium to upper-medium app weight
- High quality without unnecessary bloat
- Wi-Fi/mobile data required for online features
- App does not charge users for their carrier/ISP data
- Current prototype uses Node/Express + JSON storage
- Production should move to a real database
- Secure authentication, validation, rate limiting and media storage required

## V1 status
This package is a functional UI/backend foundation. It is intentionally not a production social network yet. Real authentication, real-time messaging/calls, production database, media storage, moderation infrastructure and payments are the next engineering phases.
